from google.cloud import bigquery
import functions_framework
import base64
import json
client = bigquery.Client()
from cloudevents.http import CloudEvent
import ast
import time
import datetime
import os
import datetime
import json
from typing import Dict, Optional

from google.cloud import tasks_v2
from google.protobuf import duration_pb2, timestamp_pb2
env = os.environ.get("GCP_PROJECT", "Specified environment variable is not set.")
if "dev" in env:
  table = "foodai-architecture-363118.Transcripts_Decibel.Interject_Status"
  transcript_table = "foodai-architecture-363118.Transcripts_Decibel.ttm_transcripts_decibel"
  cloudtask_url = "https://us-central1-wendys-ttm.cloudfunctions.net/get_final_order_dev/?orderId="
if "staging" in env:
  table = "foodai-architecture-363118.Transcripts_Decibel_staging.Interject_Status"
  transcript_table = "foodai-architecture-363118.Transcripts_Decibel_prod.ttm_transcripts_decibel"
  cloudtask_url = "https://us-central1-wendys-ttm.cloudfunctions.net/get_final_order_staging/?orderId="
if "prod" in env:
  table = "foodai-architecture-363118.Transcripts_Decibel_prod.Interject_Status"
  transcript_table = "foodai-architecture-363118.Transcripts_Decibel_prod.ttm_transcripts_decibel"
  cloudtask_url = "https://us-central1-wendys-ttm.cloudfunctions.net/get_final_order_prod/?orderId="

def create_http_task(
    project: str,
    location: str,
    queue: str,
    url: str,
    json_payload: Dict,
    # service_account_email: str,
    # audience: Optional[str] = None,
    scheduled_seconds_from_now: Optional[int] = None,
    task_id: Optional[str] = None,
) -> tasks_v2.Task:
    """Create an HTTP POST task with a JSON payload.
    Args:
        project: The project ID where the queue is located.
        location: The location where the queue is located.
        queue: The ID of the queue to add the task to.
        url: The target URL of the task.
        json_payload: The JSON payload to send.
        scheduled_seconds_from_now: Seconds from now to schedule the task for.
        task_id: ID to use for the newly created task.
        deadline_in_seconds: The deadline in seconds for task.
    Returns:
        The newly created task.
    """

    # Create a client.
    client = tasks_v2.CloudTasksClient()

    # Construct the task.
    task = tasks_v2.Task(
        http_request=tasks_v2.HttpRequest(
            http_method=tasks_v2.HttpMethod.POST,
            url=url,
            # oidc_token=tasks_v2.OidcToken(
            #     service_account_email=service_account_email,
            #     audience=audience,
            # ),
            headers={"Content-type": "application/json"},
            body=json.dumps(json_payload).encode(),
        ),
        name=(
            client.task_path(project, location, queue, task_id)
            if task_id is not None
            else None
        ),
    )

    # Convert "seconds from now" to an absolute Protobuf Timestamp
    if scheduled_seconds_from_now is not None:
        timestamp = timestamp_pb2.Timestamp()
        timestamp.FromDatetime(
            datetime.datetime.utcnow()
            + datetime.timedelta(seconds=scheduled_seconds_from_now)
        )
        task.schedule_time = timestamp

    # # Convert "deadline in seconds" to a Protobuf Duration
    # if deadline_in_seconds is not None:
    #     duration = duration_pb2.Duration()
    #     duration.FromSeconds(deadline_in_seconds)
    #     task.dispatch_deadline = duration

    # Use the client to send a CreateTaskRequest.
    return client.create_task(
        tasks_v2.CreateTaskRequest(
            # The queue to add the task to
            parent=client.queue_path(project, location, queue),
            # The task itself
            task=task,
        )
    )

# Perform a query.
@functions_framework.cloud_event
def send_to_bq(cloud_event: CloudEvent) -> None:
  bq_data_double = base64.b64decode(cloud_event.data["message"]["data"]).decode()
  bq_data = bq_data_double.replace("'", "")
  print(bq_data)
  bq_data_json = json.loads(bq_data)
  #bq_data_json = {"session_id":"testing_technical_issue","interject_status":True,"interject_type":"agent","interject_reason":None,"interject_reason_details":None,"final_pos_order_submitted":{"customer":{"firstName":"POS","lastName":"jon-testing-xyz"},"alacarteItems":[{"itemId":"14052","name":"6 Piece Crispy Chickens Nuggets","quantity":"1","modifiers":[{"modifierAction":"ADD","sourceModifierGroupId":"75100","itemId":"75100","name":"Ranch"}]}],"combos":[],"fulfillment":{"mode":"DriveThru","source":"Mobile","type":"VoiceOrderingDriveThru"}},"pos_order_response":{"customer":{"firstName":"POS","lastName":"jon-testing-xyz"},"orderId":"88046829599326","orderNumber":"1039141755","alacarteItems":[{"itemId":"14052","name":"6 pc Nugget","quantity":"1","level":"0","price":"1.49","sourceModifierGroupId":"0","modifierId":"0","modifiers":[{"modifierAction":"ADD","sourceModifierGroupId":"13631","itemId":"75100","name":"ADD Ranch Sauce"}]}],"combos":[],"failedItems":[],"subTotal":"1.49","discountTotal":"0","tax":"0","total":"1.49","orderTime":"2023-10-06T17:06:08.5284561","fulfillment":{"mode":"DriveThru","source":"Mobile","type":"VoiceOrderingDriveThru"}},"predicted_order_status":None,"order_status_feedback_by_operator":None,"requestUrl":"https://pos.dev.innovation.wendys.digital/restaurants/20500/orders","order_id":"88046829599326","store_id":None,"menu_id":None,"day_part_id":None,"response_status":400}
  if bq_data_json["pos_order_response"] is not None:
    failed_items = has_failed_items(bq_data_json["pos_order_response"])
  else:
    bq_data_json["pos_order_response"] = ""
    failed_items = False
  if "session_id" not in bq_data_json:
    session_id = None
    bq_data_json["session_id"] = None
  else:
    session_id = bq_data_json["session_id"]
  calculated_order_status,interject_reason = calculate_order_status(session_id,bq_data_json["interject_status"], bq_data_json["interject_type"],failed_items, bq_data_json["response_status"], bq_data_json["order_id"],bq_data_json["store_id"])
  ct = datetime.datetime.now()
  QUERY = (      
      'INSERT INTO '+ table +' VALUES ("{}", "{}","{}","{}","{}", "{}", "{}", "{}", "{}", "{}", "{}", "{}", "{}", "{}", "{}", "{}", "{}")'. format(session_id, bq_data_json["interject_status"], bq_data_json["interject_type"], bq_data_json["final_pos_order_submitted"], bq_data_json["pos_order_response"], bq_data_json["predicted_order_status"], bq_data_json["order_status_feedback_by_operator"], bq_data_json["requestUrl"],interject_reason,bq_data_json["interject_reason_details"], bq_data_json["order_id"], calculated_order_status, bq_data_json["store_id"], bq_data_json["menu_id"], bq_data_json["day_part_id"],ct,None )
)
  
  print(QUERY)
  query_job = client.query(QUERY)  # API request
  rows = query_job.result()  # Waits for query to finish
  return rows

def get_interject_reason(session_id):
  try:
    query = """
        SELECT
          SPLIT(conversation_name, '/')[OFFSET(7)] AS session_id,
          request_time,
          turn_position,
          STRING(derived_data.userUtterances) AS user,
          STRING(derived_data.agentUtterances) AS agent
        FROM '"""+ transcript_table + """' 
        WHERE
          TRUE
          AND project_id = 'foodai-architecture-363118'
          AND conversation_name LIKE '%{}'
        ORDER BY
          conversation_name,
          turn_position DESC
        LIMIT
          10000
        """.format(session_id)
    print(query)
    time.sleep(60)
    query_job = client.query(query)
    last_user_response=''
    last_request_time = ''
    print("QUERIED TABLE")
    for row in query_job.result():
      last_user_response = row["user"].lower()
      break
    if "crew member" in last_user_response or "person" in last_user_response:
      return "customer_requested"
    if "mobile" in last_user_response or "phone" in last_user_response:
      print("mobile")
      return "mobile"
    return None
  except: 
    print("Unable to query BQ table for transcript")


def calculate_order_status(session_id, interject_status, interject_type, has_failed_items, response_code,order_id, store_id):
  #Scenario 1: interject_status = False & POS response has no failed items
  url = cloudtask_url + order_id+"&storeId="+store_id
  json_payload= {"name" : "hello"}
  interject_reason = None
  create_http_task("wendys-ttm", "us-central1","get-final-order", url, json_payload, 60)
  if interject_status == False and has_failed_items == False:
    return "Success", interject_reason
  if interject_status == True and response_code != 200:
    return "Failure", "technical_issue"
  if interject_status == True and interject_type == "crew":
    return "Failure", interject_reason
  if interject_status == True and interject_type == "agent":
    interject_reason = get_interject_reason(session_id)
    if interject_reason == "customer_requested" or "mobile":
      return "Invalid", interject_reason
  return "Failure", interject_reason


def has_failed_items(pos_response):
  if len(pos_response['failedItems']) == 0:
    return False
  else:
    return True

